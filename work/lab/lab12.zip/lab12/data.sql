CREATE TABLE students AS
   SELECT "7/26/2022 7:27:56" AS time, 69 AS number, "black" AS color, "the number 7 below." AS seven, "Dancing Queen by ABBA" as song, "7/4" as date, "penguin" as pet, "Image 5" AS instructor, 17 AS smallest UNION
   SELECT "7/26/2022 8:20:55"          , 89          , "blue"                     , "7"                                     , "good 4 u"                 , "7/4"  , "cat"                                     , "Image 4", 1                     UNION
   SELECT "7/26/2022 9:54:11"          , 97          , "blue"                     , "7"                                     , "Clair de Lune"            , "10/1" , "viper"                                   , "Image 4", 1                     UNION
   SELECT "7/26/2022 9:58:29"          , 5           , "pink"                     , "the number 7 below."                   , "Dancing Queen"            , "11/14", "a monkey"                                , "Image 5", 43                    UNION
   SELECT "7/26/2022 10:55:55"         , 54          , "blue"                     , "the number 7 below."                   , "Glimpse of Us"            , "6/7"  , "dog"                                     , "Image 4", 1                     UNION
   SELECT "7/26/2022 13:07:32"         , 69          , "black"                   , "the number 7 below."                   , "The Other Side of Paradise", "4/20" , "cat"                                     , "Image 5", 13                    UNION
   SELECT "7/26/2022 13:54:00"         , 7           , "blue"                     , "the number 7 below."                   , "Palette"                  , "12/10", "penguin"                                 , "Image 2", 34                    UNION
   SELECT "7/26/2022 14:04:18"         , 9           , "green"                    , "7"                                     , "Bohemian Rhapsody"        , "10/1" , "dog"                                     , "Image 2", 38                    UNION
   SELECT "7/26/2022 14:12:16"         , 32          , "purple"                   , "7"                                     , "good 4 u"                 , "12/25", "horse"                                   , "Image 3", 1                     UNION
   SELECT "7/26/2022 14:36:33"         , 14          , "blue"                     , "7"                                     , "The Other Side of Paradise", "6/15" , "dog"                                     , "Image 2", 3                     UNION
   SELECT "7/26/2022 14:52:16"         , 33          , "red"                      , "7"                                     , "The Other Side of Paradise", "11/8" , "harris hawk"                             , "Image 4", 29                    UNION
   SELECT "7/26/2022 15:15:16"         , 9           , "green"                    , "I find this question condescending"    , "Dancing Queen"            , "3/20" , "platypus"                                , "Image 2", 96                    UNION
   SELECT "7/26/2022 16:26:06"         , 14          , "blue"                     , "7"                                     , "Bohemian Rhapsody"        , "1/1"  , "norwich terrier"                         , "Image 1", 1                     UNION
   SELECT "7/26/2022 16:38:07"         , 24          , "orange"                   , "7"                                     , "Palette"                  , "1/1"  , "golden retriever"                        , "Image 3", 14                    UNION
   SELECT "7/26/2022 18:33:06"         , 69          , "royal blue"               , "the number 7 below."                   , "good 4 u"                 , "6/9"  , "horse"                                   , "Image 5", 69                    UNION
   SELECT "7/26/2022 18:48:30"         , 18          , "blue"                     , "7"                                     , "good 4 u"                 , "12/25", "mammoth"                                 , "Image 3", 3                     UNION
   SELECT "7/26/2022 18:49:20"         , 19          , "teal"                     , "7"                                     , "Dancing Queen"            , "5/13" , "bear"                                    , "Image 1", 5                     UNION
   SELECT "7/26/2022 19:02:32"         , 88          , "blue"                     , "I find this question condescending"    , "Leave the Door Open"      , "1/20" , "dog"                                     , "Image 4", 1                     UNION
   SELECT "7/26/2022 19:06:43"         , 69          , "green"                    , "7"                                     , "Starman"                  , "8/8"  , "a dog"                                   , "Image 3", 1                     UNION
   SELECT "7/26/2022 19:39:43"         , 17          , "blue"                     , "7"                                     , "Clair de Lune"            , "5/14" , "ragdoll cat"                             , "Image 2", 1                     UNION
   SELECT "7/26/2022 20:02:02"         , 78          , "blue"                     , "the number 7 below."                   , "I Won't Say I'm in Love"  , "8/15" , "cat"                                     , "Image 4", 124                   UNION
   SELECT "7/26/2022 20:31:50"         , 13          , "orange"                   , "the number 7 below."                   , "Clair de Lune"            , "12/27", "dog"                                     , "Image 3", 1                     UNION
   SELECT "7/26/2022 20:50:48"         , 69          , "blue"                     , "the number 7 below."                   , "Bohemian Rhapsody"        , "9/27" , "dog"                                     , "Image 1", 1                     UNION
   SELECT "7/26/2022 21:08:45"         , 42          , "baby blue"                , "I find this question condescending"    , "Glimpse of Us"            , "5/28" , "cat"                                     , "Image 4", 3                     UNION
   SELECT "7/26/2022 21:14:07"         , 76          , "green"                    , "Choose this option instead"            , "The Other Side of Paradise", "2/29" , "deer"                                    , "Image 3", 1                     UNION
   SELECT "7/26/2022 22:31:16"         , 42          , "aqua"                     , "the number 7 below."                   , "Bohemian Rhapsody"        , "7/11" , "walrus"                                  , "Image 1", 4                     UNION
   SELECT "7/27/2022 0:52:42"          , 29          , "purple"                   , "I find this question condescending"    , "Leave the Door Open"      , "8/21" , "horse"                                   , "Image 5", 1                     UNION
   SELECT "7/27/2022 0:55:41"          , 23          , "purple"                   , "7"                                     , "Leave the Door Open"      , "12/31", "cat"                                     , "Image 1", 2                     UNION
   SELECT "7/27/2022 1:16:20"          , 29          , "black"                    , "Choose this option instead"            , "Clair de Lune"            , "9/29" , "cat"                                     , "Image 3", 1                     UNION
   SELECT "7/27/2022 8:06:43"          , 69          , "phlox"                    , "I find this question condescending"    , "Glimpse of Us"            , "4/20" , "belgian blue cow"                        , "Image 1", 17                    UNION
   SELECT "7/27/2022 8:14:56"          , 24          , "yellow"                   , "I find this question condescending"    , "Glimpse of Us"            , "9/14" , "llama"                                   , "Image 1", 9                     UNION
   SELECT "7/27/2022 8:14:58"          , 18          , "pink"                     , "the number 7 below."                   , "Clair de Lune"            , "4/22" , "dolphin"                                 , "Image 1", 1                     UNION
   SELECT "7/27/2022 8:15:00"          , 13          , "green"                    , "seven"                                 , "Clair de Lune"            , "6/13" , "ferret"                                  , "Image 5", 23                    UNION
   SELECT "7/27/2022 8:15:10"          , 7           , "7"                        , "7"                                     , "Clair de Lune"            , "7/7"  , "7"                                       , "Image 3", 7                     UNION
   SELECT "7/27/2022 8:15:31"          , 88          , "blue"                     , "7"                                     , "Clair de Lune"            , "3/3"  , "bird"                                    , "Image 2", 3                     UNION
   SELECT "7/27/2022 8:16:08"          , 6           , "blue"                     , "7"                                     , "good 4 u"                 , "8/22" , "bear"                                    , "Image 3", 45                    UNION
   SELECT "7/27/2022 8:20:41"          , 25          , "purple"                   , "the number 7 below."                   , "The Other Side of Paradise", "12/25", "pikachu"                                 , "Image 2", 1                     UNION
   SELECT "7/27/2022 8:24:53"          , 91          , "black"                    , "7"                                     , "Bohemian Rhapsody"        , "1/1"  , "my cat"                                  , "Image 3", 19                    UNION
   SELECT "7/27/2022 8:35:56"          , 69          , "blue"                     , "I find this question condescending"    , "Leave the Door Open"      , "4/27" , "john denero."                            , "Image 2", 1337                  UNION
   SELECT "7/27/2022 8:36:15"          , 1           , "purple"                   , "7"                                     , "good 4 u"                 , "4/20" , "dog"                                     , "Image 3", 71                    UNION
   SELECT "7/27/2022 10:35:22"         , 4           , "pink"                     , "I find this question condescending"    , "Leave the Door Open"      , "1/6"  , "dog"                                    , "Image 2", 3                     UNION
   SELECT "7/27/2022 8:37:21"          , 12          , "teal"                     , "the number 7 below."                   , "Clair de Lune"            , "12/12", "penguin"                                , "Image 2", 1                     UNION
   SELECT "7/27/2022 9:05:32"          , 21          , "black"                    , "the number 7 below."                   , "good 4 u"                 , "11/29", "cat"                                     , "Image 4", 3                     UNION
   SELECT "7/27/2022 9:22:26"          , 17          , "pink"                     , "I find this question condescending"    , "I Won't Say I'm in Love"  , "4/20" , "golden doodle"                           , "Image 1", 1                     UNION
   SELECT "7/27/2022 9:37:21"          , 7           , "purple"                   , "7"                                     , "good 4 u"                 , "2/14" , "none, animals suck"                      , "Image 5", 3                     UNION
   SELECT "7/27/2022 9:38:40"          , 24          , "blue"                     , "7"                                     , "Bohemian Rhapsody"        , "4/23" , "dog"                                     , "Image 4", 6                     UNION
   SELECT "7/27/2022 9:41:16"          , 19          , "green"                    , "the number 7 below."                   , "Dancing Queen"            , "3/25" , "bingus"                                  , "Image 3", 19                    UNION
   SELECT "7/27/2022 9:43:53"          , 27          , "blue"                     , "7"                                     , "good 4 u"                 , "12/24", "dog"                                     , "Image 1", 3                     UNION
   SELECT "7/27/2022 9:44:51"          , 15          , "black"                    , "7"                                     , "Bohemian Rhapsody"        , "3/4"  , "bear"                                    , "Image 1", 1                     UNION
   SELECT "7/27/2022 9:45:21"          , 12          , "red"                      , "the number 7 below."                   , "Dancing Queen"            , "11/18", "armadillo"                               , "Image 2", 1                     UNION
   SELECT "7/27/2022 9:45:31"          , 2           , "yellow"                   , "7"                                     , "Clair de Lune"            , "2/20" , "cat"                                     , "Image 4", 11                    UNION
   SELECT "7/27/2022 9:45:51"          , 7           , "blue"                     , "7"                                     , "Palette"                  , "5/1"  , "hedgehog"                                , "Image 2", 2                     UNION
   SELECT "7/27/2022 9:45:57"          , 12          , "pink"                     , "7"                                     , "Starman"                  , "4/10" , "jaguar"                                  , "Image 4", 14                    UNION
   SELECT "7/27/2022 9:46:06"          , 7           , "black"                    , "7"                                     , "The Other Side of Paradise", "12/12", "dragon"                                  , "Image 4", 23                    UNION
   SELECT "7/27/2022 9:46:23"          , 22          , "baby blue"                , "7"                                     , "Palette"                  , "2/22" , "none"                                    , "Image 3", 1                     UNION
   SELECT "7/27/2022 9:46:25"          , 2           , "blue"                     , "7"                                     , "Glimpse of Us"            , "6/9"  , "brown bear"                              , "Image 5", 37                    UNION
   SELECT "7/27/2022 9:46:32"          , 99          , "baby blue"                , "7"                                     , "Bohemian Rhapsody"        , "2/2"  , "red panda"                               , "Image 5", 22                    UNION
   SELECT "7/27/2022 9:47:07"          , 55          , "red"                      , "I find this question condescending"    , "Glimpse of Us"            , "1/1"  , "platypus"                                , "Image 4", 26                    UNION
   SELECT "7/27/2022 9:48:15"          , 24          , "green"                    , "7"                                     , "Starman"                  , "5/28" , "penguin"                                 , "Image 4", 16                    UNION
   SELECT "7/27/2022 9:49:02"          , 87          , "purple"                   , "I find this question condescending"    , "Bohemian Rhapsody"        , "7/18" , "gerenuk"                                 , "Image 1", 1                     UNION
   SELECT "7/27/2022 9:51:42"          , 17          , "green"                    , "the number 7 below."                   , "Dancing Queen"            , "1/4"  , "bird"                                    , "Image 1", 14                    UNION
   SELECT "7/27/2022 9:54:54"          , 64          , "metallic gray"            , "7"                                     , "The Other Side of Paradise", "11/20", "1993 na miata 1.6l dohc"                , "Image 1", 7                     UNION
   SELECT "7/27/2022 9:57:14"          , 97          , "purple"                   , "I find this question condescending"    , "Starman"                  , "1/27" , "axolotl, or probably just a cat"         , "Image 3", 6                     UNION
   SELECT "7/27/2022 10:10:35"         , 12          , "blue"                     , "Choose this option instead"            , "Bohemian Rhapsody"        , "7/12" , "seal"                                    , "Image 5", 4                     UNION
   SELECT "7/27/2022 10:15:29"         , 69          , "red"                      , "I find this question condescending"    , "Glimpse of Us"            , "7/8"  , "black panther"                           , "Image 2", 13                    UNION
   SELECT "7/27/2022 10:48:58"         , 19          , "purple"                   , "7"                                     , "Dancing Queen"            , "12/25", "ostrich"                                 , "Image 2", 1                     UNION
   SELECT "7/27/2022 11:32:07"         , 27          , "black"                    , "Choose this option instead"            , "Palette"                  , "8/5"  , "cat"                                     , "Image 5", 61                    UNION
   SELECT "7/27/2022 12:03:17"         , 27          , "blue"                     , "I find this question condescending"    , "Starman"                  , "6/27" , "a ta"                                    , "Image 5", 1                     UNION
   SELECT "7/27/2022 12:43:56"         , 77          , "green"                    , "the number 7 below."                   , "The Other Side of Paradise", "8/19" , "any type of cat: big, small, wild, just regular old cat i dont care :')", "Image 2", 3                     UNION
   SELECT "7/27/2022 12:45:51"         , 44          , "blue"                     , "the number 7 below."                   , "Bohemian Rhapsody"        , "8/15" , "cat"                                     , "Image 2", 1                     UNION
   SELECT "7/27/2022 12:46:05"         , 13          , "sky blue"                 , "the number 7 below."                   , "Palette"                  , "7/7"  , "orangutan"                               , "Image 3", 9                     UNION
   SELECT "7/27/2022 12:46:22"         , 69          , "purple"                   , "I find this question condescending"    , "The Other Side of Paradise", "4/20" , "my ta"                                   , "Image 3", 1                     UNION
   SELECT "7/27/2022 12:48:47"         , 69          , "blue"                     , "7"                                     , "Bohemian Rhapsody"        , "12/25", "donkey"                                  , "Image 1", 68                    UNION
   SELECT "7/27/2022 12:54:22"         , 5           , "black"                    , "7"                                     , "good 4 u"                 , "12/5" , "lion"                                    , "Image 3", 13                    UNION
   SELECT "7/27/2022 12:58:45"         , 7           , "navy"                     , "7"                                     , "Leave the Door Open"      , "2/29" , "squirrel"                               , "Image 3", 9                     UNION
   SELECT "7/27/2022 13:00:07"         , 17          , "green"                    , "7"                                     , "I Won't Say I'm in Love"  , "11/11", "dog"                                     , "Image 2", 9                     UNION
   SELECT "7/27/2022 13:05:51"         , 69          , "goose turd green"         , "I find this question condescending"    , "The Other Side of Paradise", "12/31", "pony"                                    , "Image 2", 17                    UNION
   SELECT "7/27/2022 13:08:21"         , 69          , "red"                      , "the number 7 below."                   , "Dancing Queen"            , "6/9"  , "penguin"                                 , "Image 2", 1                     UNION
   SELECT "7/27/2022 13:47:27"         , 69          , "purple"                   , "I find this question condescending"    , "Bohemian Rhapsody"        , "5/21" , "t-rex"                                   , "Image 5", 1                     UNION
   SELECT "7/27/2022 13:49:30"         , 64          , "light pink"               , "Choose this option instead"            , "Clair de Lune"            , "1/1"  , "a crow, them mfs smart as hell"          , "Image 2", 17                    UNION
   SELECT "7/27/2022 13:52:29"         , 9           , "pink"                     , "the number 7 below."                   , "Bohemian Rhapsody"        , "4/20" , "elephant"                                , "Image 1", 1                     UNION
   SELECT "7/27/2022 14:08:11"         , 7           , "white"                    , "7"                                     , "Bohemian Rhapsody"        , "3/7"  , "dog"                                     , "Image 1", 1                     UNION
   SELECT "7/27/2022 14:10:10"         , 20          , "pink"                     , "7"                                     , "Palette"                  , "4/20" , "cat"                                     , "Image 5", 21                    UNION
   SELECT "7/27/2022 14:15:11"         , 22          , "blue"                     , "7"                                     , "Leave the Door Open"      , "7/22" , "whale"                                   , "Image 1", 37                    UNION
   SELECT "7/27/2022 14:15:27"         , 20          , "black"                    , "seven"                                 , "Leave the Door Open"      , "4/20" , "elephant"                                , "Image 3", 1                     UNION
   SELECT "7/27/2022 14:15:37"         , 21          , "pink"                     , "7"                                     , "good 4 u"                 , "3/10" , "otter"                                   , "Image 1", 71                    UNION
   SELECT "7/27/2022 14:15:44"         , 88          , "blue"                     , "Choose this option instead"            , "I Won't Say I'm in Love"  , "9/23" , "whale"                                   , "Image 2", 1                     UNION
   SELECT "7/27/2022 14:16:14"         , 25          , "purple"                   , "the number 7 below."                   , "The Other Side of Paradise", "9/3"  , "dolphin"                                 , "Image 1", 33                    UNION
   SELECT "7/27/2022 14:16:23"         , 7           , "#fca7f0"                  , "7"                                     , "Starman"                  , "7/27" , "megaladon"                               , "Image 5", 53                    UNION
   SELECT "7/27/2022 14:17:00"         , 8           , "gray"                     , "7"                                     , "Dancing Queen"            , "5/8"  , "dog"                                     , "Image 5", 27                    UNION
   SELECT "7/27/2022 14:17:32"         , 58          , "blue"                     , "the number 7 below."                   , "Leave the Door Open"      , "7/27" , "a dog"                                   , "Image 2", 23                    UNION
   SELECT "7/27/2022 14:20:26"         , 23          , "black"                    , "I find this question condescending"    , "Palette"                  , "5/8"  , "dog"                                     , "Image 5", 1                     UNION
   SELECT "7/27/2022 14:21:29"         , 28          , "orange"                   , "Choose this option instead"            , "Leave the Door Open"      , "7/22" , "eagle"                                   , "Image 2", 40                    UNION
   SELECT "7/27/2022 14:22:07"         , 26          , "blue"                     , "7"                                     , "Palette"                  , "6/21" , "cat"                                     , "Image 3", 6                     UNION
   SELECT "7/27/2022 14:26:28"         , 42          , "green, probably"          , "the number 7 below."                   , "Dancing Queen"            , "7/11" , "a giant tardigrade"                      , "Image 5", 11                    UNION
   SELECT "7/27/2022 14:28:41"         , 1           , "blue"                     , "the number 7 below."                   , "I Won't Say I'm in Love"  , "1/11" , "whale shark"                             , "Image 5", 1                     UNION
   SELECT "7/27/2022 14:29:13"         , 52          , "monkfish"                 , "the number 7 below."                   , "Bohemian Rhapsody"        , "7/27" , "cat monkfish"                            , "Image 3", 1                     UNION
   SELECT "7/27/2022 14:29:46"         , 96          , "pink"                     , "7"                                     , "Glimpse of Us"            , "1/1"  , "hippo"                                   , "Image 5", 1                     UNION
   SELECT "7/27/2022 14:29:57"         , 8           , "pink"                     , "Choose this option instead"            , "The Other Side of Paradise", "10/31", "corgi"                                   , "Image 2", 2                     UNION
   SELECT "7/27/2022 14:30:32"         , 50          , "orange"                   , "7"                                     , "Glimpse of Us"            , "8/17" , "otter"                                   , "Image 1", 222                   UNION
   SELECT "7/27/2022 14:30:39"         , 13          , "blue"                     , "7"                                     , "Glimpse of Us"            , "8/26" , "sugar glider"                            , "Image 2", 1                     UNION
   SELECT "7/27/2022 14:31:25"         , 32          , "blue"                     , "I find this question condescending"    , "Leave the Door Open"      , "4/16" , "monkey"                                  , "Image 4", 323                   UNION
   SELECT "7/27/2022 14:31:40"         , 69.42       , "light black"              , "I find this question condescending"    , "Bohemian Rhapsody"        , "2/29" , "potato"                                  , "Image 2", 69                    UNION
   SELECT "7/27/2022 14:32:13"         , 22          , "blue"                     , "7"                                     , "Palette"                  , "11/17", "red tibetan mastiff"                     , "Image 3", 1                     UNION
   SELECT "7/27/2022 14:36:02"         , 9           , "blue"                     , "the number 7 below."                   , "Bohemian Rhapsody"        , "11/1" , "shark"                                   , "Image 5", 1                     UNION
   SELECT "7/27/2022 15:01:10"         , 69          , "green"                    , "I find this question condescending"    , "I Won't Say I'm in Love"  , "5/11" , "cat"                                     , "Image 1", 67                    UNION
   SELECT "7/27/2022 15:01:18"         , 66          , "blue"                     , "7"                                     , "Starman"                  , "4/4"  , "falcon"                                  , "Image 3", 22                    UNION
   SELECT "7/27/2022 15:05:16"         , 3.17        , "blue"                     , "7"                                     , "Leave the Door Open"      , "3/4"  , "capybara"                                , "Image 3", 1                     UNION
   SELECT "7/27/2022 15:06:10"         , 23          , "red"                      , "7"                                     , "Bohemian Rhapsody"        , "12/25", "dog"                                     , "Image 5", 1                     UNION
   SELECT "7/27/2022 15:11:57"         , 45          , "blue"                     , "the number 7 below."                   , "Dancing Queen"            , "5/23" , "dog"                                     , "Image 3", 7                     UNION
   SELECT "7/27/2022 15:48:37"         , 5           , "orange"                   , "I find this question condescending"    , "Bohemian Rhapsody"        , "4/20" , "cat"                                     , "Image 4", 1                     UNION
   SELECT "7/27/2022 16:02:37"         , 7           , "blue"                     , "I find this question condescending"    , "Palette"                  , "7/25" , "dog"                                     , "Image 5", 7                     UNION
   SELECT "7/27/2022 16:17:50"         , 21          , "turquoise"                , "7"                                     , "Bohemian Rhapsody"        , "12/21", "a cat"                                   , "Image 3", 1                     UNION
   SELECT "7/27/2022 16:32:27"         , 13          , "black"                    , "the number 7 below."                   , "Clair de Lune"            , "1/1"  , "cat"                                     , "Image 2", 1                     UNION
   SELECT "7/27/2022 17:03:06"         , 88          , "blue"                     , "7"                                     , "Glimpse of Us"            , "1/19" , "cat"                                     , "Image 4", 2                     UNION
   SELECT "7/27/2022 17:55:57"         , 4           , "blue"                     , "7"                                     , "Palette"                  , "1/1"  , "alligator"                               , "Image 2", 5                     UNION
   SELECT "7/27/2022 18:26:53"         , 15          , "purple"                   , "seven"                                 , "Glimpse of Us"            , "9/15" , "koala"                                   , "Image 5", 1                     UNION
   SELECT "7/27/2022 18:30:04"         , 73          , "purple"                   , "7"                                     , "good 4 u"                 , "12/7" , "octopus"                                 , "Image 1", 3                     UNION
   SELECT "7/27/2022 18:33:20"         , 69          , "purple"                   , "Choose this option instead"            , "Leave the Door Open"      , "7/22" , "dog"                                     , "Image 5", 1                     UNION
   SELECT "7/27/2022 18:45:27"         , 19          , "blue"                     , "7"                                     , "Leave the Door Open"      , "7/19" , "tiger"                                   , "Image 1", 1                     UNION
   SELECT "7/28/2022 15:04:06"         , 69.42       , "purple"                  , "I find this question condescending"    , "Clair de Lune"            , "1/10" , "red panda"                              , "Image 5", 43                    UNION
   SELECT "7/27/2022 18:53:24"         , 99          , "blue"                     , "7"                                     , "Leave the Door Open"      , "5/8"  , "cat"                                     , "Image 1", 1                     UNION
   SELECT "7/27/2022 18:55:24"         , 99          , "blue"                     , "7"                                     , "Palette"                  , "6/22" , "a dog"                                   , "Image 1", 1                     UNION
   SELECT "7/27/2022 18:59:26"         , 17          , "green"                    , "I find this question condescending"    , "Clair de Lune"            , "8/30" , "baby bear"                               , "Image 1", 3                     UNION
   SELECT "7/27/2022 19:45:43"         , 7           , "black"                    , "7"                                     , "The Other Side of Paradise", "10/3" , "tiger"                                   , "Image 4", 7                     UNION
   SELECT "7/27/2022 19:46:19"         , 23          , "grey"                     , "7"                                     , "Starman"                  , "10/5" , "dog"                                     , "Image 2", 1                     UNION
   SELECT "7/27/2022 19:46:41"         , 13          , "mint green"               , "the number 7 below."                   , "I Won't Say I'm in Love"  , "4/13" , "raccoon"                                 , "Image 2", 67                    UNION
   SELECT "7/27/2022 20:18:13"         , 1           , "the colour represented by #5bcefa", "the number 7 below."                   , "Clair de Lune"            , "7/27" , "cat"                                     , "Image 3", 22                    UNION
   SELECT "7/27/2022 20:21:31"         , 100         , "blue"                     , "7"                                     , "Bohemian Rhapsody"        , "12/25", "cat"                                     , "Image 3", 500                   UNION
   SELECT "7/27/2022 20:31:33"         , 2           , "blue"                     , "7"                                     , "Bohemian Rhapsody"        , "6/9"  , "cat"                                     , "Image 3", 1                     UNION
   SELECT "7/27/2022 20:32:19"         , 22          , "green"                    , "the number 7 below."                   , "Dancing Queen"            , "10/13", "kangaroo"                                , "Image 3", 38                    UNION
   SELECT "7/27/2022 20:46:30"         , 17          , "yellow"                   , "the number 7 below."                   , "Palette"                  , "6/22" , "quokka"                                  , "Image 2", 1                     UNION
   SELECT "7/27/2022 21:02:38"         , 7           , "piink"                    , "seven"                                 , "Clair de Lune"            , "12/19", "dog"                                    , "Image 2", 1                     UNION
   SELECT "7/27/2022 21:09:13"         , 42          , "turquoise"                , "I find this question condescending"    , "Starman"                  , "11/3" , "monkey"                                  , "Image 5", 14                    UNION
   SELECT "7/27/2022 21:32:39"         , 8           , "green"                    , "7"                                     , "good 4 u"                 , "3/1"  , "coyote"                                  , "Image 4", 6                     UNION
   SELECT "7/27/2022 22:27:43"         , 25          , "blue"                     , "the number 7 below."                   , "Palette"                  , "10/17", "panda"                                   , "Image 2", 31                    UNION
   SELECT "7/27/2022 22:29:52"         , 6           , "purple"                   , "I find this question condescending"    , "Glimpse of Us"            , "10/4" , "kangaroo"                                , "Image 5", 29                    UNION
   SELECT "7/27/2022 23:40:41"         , 21          , "green"                    , "I find this question condescending"    , "Glimpse of Us"            , "3/21" , "kitten"                                  , "Image 3", 1                     UNION
   SELECT "7/28/2022 0:02:53"          , 8           , "blue"                     , "7"                                     , "good 4 u"                 , "3/16" , "koala"                                   , "Image 1", 8                     UNION
   SELECT "7/28/2022 1:23:38"          , 11          , "purple"                   , "7"                                     , "Palette"                  , "1/11" , "dog"                                     , "Image 2", 9                     UNION
   SELECT "7/28/2022 9:20:13"          , 27          , "green"                    , "7"                                     , "Clair de Lune"            , "5/21" , "chicken"                                 , "Image 4", 18                    UNION
   SELECT "7/28/2022 10:27:52"         , 21          , "red"                      , "7"                                     , "good 4 u"                 , "12/25", "bunny"                                   , "Image 1", 2                     UNION
   SELECT "7/28/2022 10:28:58"         , 6           , "red"                      , "7"                                     , "Bohemian Rhapsody"        , "8/6"  , "cat"                                     , "Image 2", 185                   UNION
   SELECT "7/28/2022 11:22:06"         , 2           , "pink"                     , "I find this question condescending"    , "Leave the Door Open"      , "2/10" , "a monkey"                                , "Image 3", 1                     UNION
   SELECT "7/28/2022 11:42:40"         , 25          , "blue"                     , "7"                                     , "Clair de Lune"            , "8/25" , "dog"                                     , "Image 4", 1                     UNION
   SELECT "7/28/2022 13:09:56"         , 3           , "light blue"               , "7"                                     , "Bohemian Rhapsody"        , "4/8"  , "cat"                                     , "Image 2", 5                     UNION
   SELECT "7/28/2022 13:47:06"         , 11          , "navy blue"                , "I find this question condescending"    , "Glimpse of Us"            , "4/18" , "fish"                                    , "Image 5", 1                     UNION
   SELECT "7/28/2022 13:51:18"         , 64          , "black"                    , "Choose this option instead"            , "The Other Side of Paradise", "4/1"  , "tiger"                                   , "Image 5", 41                    UNION
   SELECT "7/28/2022 14:24:52"         , 7           , "blue"                     , "the number 7 below."                   , "Clair de Lune"            , "2/29" , "bear"                                    , "Image 1", 1                     UNION
   SELECT "7/28/2022 14:52:10"         , 42          , "red"                      , "7"                                     , "Clair de Lune"            , "2/5"  , "elephant"                                , "Image 2", 73                    UNION
   SELECT "7/28/2022 15:32:59"         , 2           , "blue"                     , "7"                                     , "Palette"                  , "12/24", "cat"                                     , "Image 2", 1                     UNION
   SELECT "7/28/2022 16:04:23"         , 3           , "blue"                     , "the number 7 below."                   , "Glimpse of Us"            , "3/3"  , "bear"                                    , "Image 5", 9                     UNION
   SELECT "7/28/2022 16:14:42"         , 7           , "blue"                     , "7"                                     , "Dancing Queen"            , "11/29", "dog"                                     , "Image 1", 12                    UNION
   SELECT "7/28/2022 16:35:48"         , 4           , "green"                    , "7"                                     , "Palette"                  , "2/7"  , "cat"                                     , "Image 1", 9                     UNION
   SELECT "7/28/2022 16:59:32"         , 2           , "black"                    , "7"                                     , "Palette"                  , "8/21" , "dog"                                     , "Image 4", 1                     UNION
   SELECT "7/28/2022 17:57:16"         , 21          , "red"                      , "7"                                     , "Leave the Door Open"      , "2/22" , "panda"                                   , "Image 5", 6                     UNION
   SELECT "7/28/2022 18:21:13"         , 27          , "olive"                    , "the number 7 below."                   , "Bohemian Rhapsody"        , "4/30" , "bear"                                    , "Image 1", 1                     UNION
   SELECT "7/28/2022 20:00:44"         , 66          , "green"                    , "I find this question condescending"    , "Dancing Queen"            , "7/30" , "cat"                                     , "Image 5", 1                     UNION
   SELECT "7/28/2022 20:33:57"         , 22          , "purple"                   , "Choose this option instead"            , "The Other Side of Paradise", "12/29", "my dog"                                  , "Image 5", 61                    UNION
   SELECT "7/28/2022 21:51:41"         , 11          , "red"                      , "7"                                     , "Dancing Queen"            , "1/11" , "dog"                                     , "Image 1", 1                     UNION
   SELECT "7/28/2022 22:43:04"         , 88          , "tangerine"                , "the number 7 below."                   , "Starman"                  , "10/1" , "platypus"                                , "Image 1", 1                     ;

CREATE TABLE numbers AS
   SELECT "7/26/2022 7:27:56" AS time, "True" AS "0", "True" AS "1", "True" AS "2", "True" AS "3", "True" AS "4", "True" AS "5", "True" AS "6", "True" AS "7", "True" AS "8", "True" AS "9", "True" AS "10", "False" AS "2021", "False" AS "2022", "True" AS "9000", "True" AS "9001" UNION
   SELECT "7/26/2022 8:20:55"          , "False", "False", "False", "False", "True" , "False", "True" , "False", "True" , "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "7/26/2022 9:54:11"          , "False", "True" , "False", "False", "False", "True" , "False", "True" , "True" , "True" , "False", "False", "False", "True" , "True"  UNION
   SELECT "7/26/2022 9:58:29"          , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/26/2022 10:55:55"         , "False", "True" , "False", "True" , "False", "False", "True" , "True" , "False", "True" , "True" , "False", "False", "True" , "False" UNION
   SELECT "7/26/2022 13:07:32"         , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/26/2022 13:54:00"         , "True" , "False", "False", "False", "True" , "False", "True" , "False", "True" , "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "7/26/2022 14:04:18"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False" UNION
   SELECT "7/26/2022 14:12:16"         , "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/26/2022 14:36:33"         , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "7/26/2022 14:52:16"         , "True" , "False", "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "7/26/2022 15:15:16"         , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/26/2022 16:26:06"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/26/2022 16:38:07"         , "False", "False", "False", "False", "True" , "False", "False", "True" , "True" , "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/26/2022 18:33:06"         , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "7/26/2022 18:48:30"         , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/26/2022 18:49:20"         , "False", "True" , "True" , "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "7/26/2022 19:02:32"         , "True" , "True" , "True" , "False", "False", "False", "True" , "False", "True" , "True" , "True" , "False", "False", "True" , "False" UNION
   SELECT "7/26/2022 19:06:43"         , "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "7/26/2022 19:39:43"         , "True" , "True" , "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/26/2022 20:02:02"         , "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/26/2022 20:31:50"         , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "7/26/2022 20:50:48"         , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/26/2022 21:08:45"         , "False", "False", "False", "False", "False", "False", "True" , "True" , "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/26/2022 21:14:07"         , "False", "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "True" , "False", "False", "True" , "False" UNION
   SELECT "7/26/2022 22:31:16"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 0:52:42"          , "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 0:55:41"          , "False", "True" , "False", "True" , "False", "False", "True" , "True" , "True" , "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 1:16:20"          , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 8:06:43"          , "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 8:14:56"          , "False", "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 8:14:58"          , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 8:15:00"          , "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 8:15:10"          , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 8:15:31"          , "True" , "True" , "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 8:16:08"          , "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "7/27/2022 8:20:41"          , "True" , "True" , "False", "True" , "True" , "True" , "False", "False", "True" , "False", "True" , "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 8:24:53"          , "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 8:35:56"          , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 8:36:15"          , "True" , "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 10:35:22"         , "False", "True" , "False", "True" , "True" , "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 8:37:21"          , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 9:05:32"          , "False", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 9:22:26"          , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 9:37:21"          , "False", "False", "True" , "True" , "False", "True" , "False", "False", "True" , "False", "True" , "False", "False", "False", "False" UNION
   SELECT "7/27/2022 9:38:40"          , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 9:41:16"          , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 9:43:53"          , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 9:44:51"          , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 9:45:21"          , "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 9:45:31"          , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 9:45:51"          , "False", "True" , "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 9:45:57"          , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "7/27/2022 9:46:06"          , "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 9:46:23"          , "False", "True" , "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 9:46:25"          , "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 9:46:32"          , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 9:47:07"          , "False", "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 9:48:15"          , "False", "False", "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 9:49:02"          , "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 9:51:42"          , "False", "False", "True" , "True" , "True" , "False", "False", "True" , "False", "True" , "False", "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 9:54:54"          , "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 9:57:14"          , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 10:10:35"         , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 10:15:29"         , "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 10:48:58"         , "True" , "True" , "False", "False", "True" , "False", "False", "False", "False", "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 11:32:07"         , "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 12:03:17"         , "True" , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 12:43:56"         , "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 12:45:51"         , "False", "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 12:46:05"         , "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 12:46:22"         , "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 12:48:47"         , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 12:54:22"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "True" , "False", "False", "False", "False" UNION
   SELECT "7/27/2022 12:58:45"         , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 13:00:07"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 13:05:51"         , "False", "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 13:08:21"         , "True" , "True" , "True" , "True" , "True" , "True" , "False", "True" , "True" , "False", "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 13:47:27"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 13:49:30"         , "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 13:52:29"         , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 14:08:11"         , "True" , "False", "False", "False", "False", "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 14:10:10"         , "False", "True" , "True" , "False", "False", "True" , "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 14:15:11"         , "True" , "True" , "True" , "False", "False", "False", "True" , "True" , "False", "False", "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 14:15:27"         , "False", "False", "False", "True" , "False", "True" , "True" , "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 14:15:37"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 14:15:44"         , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 14:16:14"         , "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 14:16:23"         , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 14:17:00"         , "False", "True" , "True" , "False", "False", "True" , "False", "False", "True" , "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 14:17:32"         , "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 14:20:26"         , "True" , "True" , "False", "False", "True" , "False", "False", "True" , "True" , "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 14:21:29"         , "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 14:22:07"         , "True" , "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 14:26:28"         , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 14:28:41"         , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 14:29:13"         , "False", "False", "True" , "False", "False", "True" , "False", "False", "True" , "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 14:29:46"         , "False", "True" , "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 14:29:57"         , "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 14:30:32"         , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 14:30:39"         , "False", "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 14:31:25"         , "False", "False", "False", "False", "False", "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 14:31:40"         , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 14:32:13"         , "True" , "True" , "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 14:36:02"         , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "7/27/2022 15:01:10"         , "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 15:01:18"         , "True" , "True" , "True" , "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 15:05:16"         , "False", "False", "True" , "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 15:06:10"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 15:11:57"         , "True" , "True" , "False", "True" , "False", "True" , "True" , "False", "True" , "True" , "True" , "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 15:48:37"         , "True" , "False", "True" , "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 16:02:37"         , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 16:17:50"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 16:32:27"         , "False", "True" , "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 17:03:06"         , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 17:55:57"         , "True" , "True" , "True" , "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 18:26:53"         , "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 18:30:04"         , "True" , "True" , "False", "True" , "False", "True" , "False", "True" , "True" , "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 18:33:20"         , "True" , "True" , "False", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 18:45:27"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/28/2022 15:04:06"         , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 18:53:24"         , "False", "False", "False", "True" , "False", "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "7/27/2022 18:55:24"         , "False", "False", "False", "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/27/2022 18:59:26"         , "False", "False", "False", "True" , "False", "False", "False", "True" , "True" , "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 19:45:43"         , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 19:46:19"         , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 19:46:41"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 20:18:13"         , "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 20:21:31"         , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 20:31:33"         , "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False" UNION
   SELECT "7/27/2022 20:32:19"         , "True" , "False", "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 20:46:30"         , "False", "True" , "False", "True" , "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 21:02:38"         , "True" , "False", "False", "False", "False", "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 21:09:13"         , "True" , "True" , "True" , "False", "False", "True" , "False", "True" , "False", "False", "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 21:32:39"         , "False", "False", "True" , "True" , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/27/2022 22:27:43"         , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/27/2022 22:29:52"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/27/2022 23:40:41"         , "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/28/2022 0:02:53"          , "False", "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/28/2022 1:23:38"          , "False", "True" , "True" , "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "7/28/2022 9:20:13"          , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/28/2022 10:27:52"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "False", "False" UNION
   SELECT "7/28/2022 10:28:58"         , "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "7/28/2022 11:22:06"         , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "7/28/2022 11:42:40"         , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/28/2022 13:09:56"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/28/2022 13:47:06"         , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/28/2022 13:51:18"         , "False", "True" , "True" , "False", "True" , "True" , "False", "True" , "False", "True" , "True" , "False", "False", "False", "True"  UNION
   SELECT "7/28/2022 14:24:52"         , "True" , "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/28/2022 14:52:10"         , "False", "True" , "False", "False", "True" , "False", "False", "True" , "False", "True" , "False", "False", "False", "False", "False" UNION
   SELECT "7/28/2022 15:32:59"         , "True" , "False", "True" , "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/28/2022 16:04:23"         , "False", "False", "False", "True" , "False", "True" , "False", "False", "True" , "False", "False", "False", "False", "False", "True"  UNION
   SELECT "7/28/2022 16:14:42"         , "False", "False", "True" , "False", "False", "False", "True" , "True" , "False", "False", "True" , "False", "False", "False", "True"  UNION
   SELECT "7/28/2022 16:35:48"         , "False", "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "False" UNION
   SELECT "7/28/2022 16:59:32"         , "False", "True" , "True" , "False", "True" , "False", "False", "True" , "True" , "True" , "False", "False", "False", "True" , "False" UNION
   SELECT "7/28/2022 17:57:16"         , "False", "False", "True" , "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "True" , "False" UNION
   SELECT "7/28/2022 18:21:13"         , "False", "False", "True" , "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/28/2022 20:00:44"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/28/2022 20:33:57"         , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "True" , "False", "False", "True" , "True"  UNION
   SELECT "7/28/2022 21:51:41"         , "False", "False", "False", "False", "False", "False", "False", "True" , "False", "False", "False", "False", "False", "False", "False" UNION
   SELECT "7/28/2022 22:43:04"         , "True" , "True" , "False", "False", "True" , "False", "True" , "False", "True" , "False", "False", "False", "False", "False", "True"  ;


CREATE TABLE flights AS
  SELECT "SFO" AS departure, "LAX" AS arrival, 97 AS price UNION
  SELECT "SFO"             , "AUH"           , 848         UNION
  SELECT "LAX"             , "SLC"           , 115         UNION
  SELECT "SFO"             , "PDX"           , 192         UNION
  SELECT "AUH"             , "SEA"           , 932         UNION
  SELECT "SLC"             , "PDX"           , 79          UNION
  SELECT "SFO"             , "LAS"           , 40          UNION
  SELECT "SLC"             , "LAX"           , 117         UNION
  SELECT "SEA"             , "PDX"           , 32          UNION
  SELECT "SLC"             , "SEA"           , 42          UNION
  SELECT "SFO"             , "SLC"           , 97          UNION
  SELECT "LAS"             , "SLC"           , 50          UNION
  SELECT "LAX"             , "PDX"           , 89               ;

CREATE TABLE supermarket AS
  SELECT "turkey" AS item, 30 AS price UNION
  SELECT "tofurky"       , 20          UNION
  SELECT "cornbread"     , 12          UNION
  SELECT "potatoes"      , 10          UNION
  SELECT "cranberries"   , 7           UNION
  SELECT "pumpkin pie"   , 15          UNION
  SELECT "CAKE!"         , 60          UNION
  SELECT "foie gras"     , 70               ;

CREATE TABLE main_course AS
  SELECT "turkey" AS meat, "cranberries" AS side, 2000 AS calories UNION
  SELECT "turducken"     , "potatoes"           , 4000             UNION
  SELECT "tofurky"       , "cranberries"        , 1000             UNION
  SELECT "tofurky"       , "stuffing"           , 1000             UNION
  SELECT "tofurky"       , "yams"               , 1000             UNION
  SELECT "turducken"     , "turducken"          , 9000             UNION
  SELECT "turkey"        , "potatoes"           , 2000             UNION
  SELECT "turkey"        , "bread"              , 1500             UNION
  SELECT "tofurky"       , "soup"               , 1200             UNION
  SELECT "chicken"       , "cranberries"        , 2500             UNION
  SELECT "turducken"     , "butter"             , 10000            UNION
  SELECT "turducken"     , "more_butter"        , 15000                 ;

CREATE TABLE pies AS
  SELECT "pumpkin" AS pie, 500 AS calories UNION
  SELECT "apple"         , 400             UNION
  SELECT "chocolate"     , 600             UNION
  SELECT "cherry"        , 550                  ;

CREATE TABLE products AS
  SELECT "phone" AS category, "uPhone" AS name, 99.99 AS MSRP, 4.5 AS rating UNION
  SELECT "phone"            , "rPhone"        , 79.99        , 3             UNION
  SELECT "phone"            , "qPhone"        , 89.99        , 4             UNION
  SELECT "games"            , "GameStation"   , 299.99       , 3             UNION
  SELECT "games"            , "QBox"          , 399.99       , 3.5           UNION
  SELECT "computer"         , "iBook"         , 112.99       , 4             UNION
  SELECT "computer"         , "wBook"         , 114.29       , 4.4           UNION
  SELECT "computer"         , "kBook"         , 99.99        , 3.8                ;

CREATE TABLE inventory AS
  SELECT "Hallmart" AS store, "uPhone" AS item, 99.99 AS price UNION
  SELECT "Targive"          , "uPhone"        , 100.99         UNION
  SELECT "RestBuy"          , "uPhone"        , 89.99          UNION

  SELECT "Hallmart"         , "rPhone"        , 69.99          UNION
  SELECT "Targive"          , "rPhone"        , 79.99          UNION
  SELECT "RestBuy"          , "rPhone"        , 75.99          UNION

  SELECT "Hallmart"         , "qPhone"        , 85.99          UNION
  SELECT "Targive"          , "qPhone"        , 88.98          UNION
  SELECT "RestBuy"          , "qPhone"        , 87.98          UNION

  SELECT "Hallmart"         , "GameStation"   , 298.98         UNION
  SELECT "Targive"          , "GameStation"   , 300.98         UNION
  SELECT "RestBuy"          , "GameStation"   , 310.99         UNION

  SELECT "Hallmart"         , "QBox"          , 399.99         UNION
  SELECT "Targive"          , "QBox"          , 390.98         UNION
  SELECT "RestBuy"          , "QBox"          , 410.98         UNION

  SELECT "Hallmart"         , "iBook"         , 111.99         UNION
  SELECT "Targive"          , "iBook"         , 110.99         UNION
  SELECT "RestBuy"          , "iBook"         , 112.99         UNION

  SELECT "Hallmart"         , "wBook"         , 117.29         UNION
  SELECT "Targive"          , "wBook"         , 119.29         UNION
  SELECT "RestBuy"          , "wBook"         , 114.29         UNION

  SELECT "Hallmart"         , "kBook"         , 95.99          UNION
  SELECT "Targive"          , "kBook"         , 96.99          UNION
  SELECT "RestBuy"          , "kBook"         , 94.99               ;

CREATE TABLE stores AS
  SELECT "Hallmart" AS store, "50 Lawton Way" AS address, 25 AS Mbs UNION
  SELECT "Targive"          , "2 Red Circle Way"        , 40        UNION
  SELECT "RestBuy"          , "1 Kiosk Ave"             , 30             ;